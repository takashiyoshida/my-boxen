#FastScripts
[![Build Status](https://travis-ci.org/takashiyoshida/puppet-fastscripts.png?branch=travis)](https://travis-ci.org/takashiyoshida/puppet-fastscripts)

Install [FastScripts](http://www.red-sweater.com/fastscripts/) on OS X.

## Usage

```puppet
include fastscripts
```

## Required Puppet Modules

* `boxen`
* `stdlib`

## Development

Write some code. Run `script/cibuild` to test it. Check the `script` directory for other useful tools.
