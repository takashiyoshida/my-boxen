<<<<<<< HEAD
# Undercover Puppet Module for Boxen
[![Build Status](https://travis-ci.org/boxen/puppet-undercover.png?branch=master)](https://travis-ci.org/boxen/puppet-undercover)

## Usage

```puppet
include undercover
```

## Required Puppet Modules

* `boxen`
* `stdlib`

## Developing

Write code.

Run `script/cibuild`.
