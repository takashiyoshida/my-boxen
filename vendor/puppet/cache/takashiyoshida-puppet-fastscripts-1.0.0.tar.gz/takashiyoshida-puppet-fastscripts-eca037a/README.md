#FastScripts

## Usage

```puppet
include fastscripts
```

## Required Puppet Modules

* `boxen`

## Development

Write some code. Run `script/cibuild` to test it. Check the `script`
directory for other useful tools.
