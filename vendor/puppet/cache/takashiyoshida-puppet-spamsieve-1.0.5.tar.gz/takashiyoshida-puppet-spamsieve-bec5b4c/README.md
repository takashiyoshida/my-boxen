#SpamSieve
[![Build Status](https://travis-ci.org/takashiyoshida/puppet-spamsieve.png?branch=travis)](https://travis-ci.org/takashiyoshida/puppet-spamsieve)

Install [SpamSieve](http://c-command.com/spamsieve/) on OS X.

## Usage

```puppet
include spamsieve
```

## Required Puppet Modules

* `boxen`

## Development

Write some code. Run `script/cibuild` to test it. Check the `script`
directory for other useful tools.
